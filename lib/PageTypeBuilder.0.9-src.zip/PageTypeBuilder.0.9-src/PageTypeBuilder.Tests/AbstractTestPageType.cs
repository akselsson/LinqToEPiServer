﻿namespace PageTypeBuilder.Tests
{
    [PageType]
    public abstract class AbstractTestPageType : TypedPageData
    {
    }
}
