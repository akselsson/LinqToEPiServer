﻿namespace PageTypeBuilder.Tests
{
    public abstract class TestTabAbstract : Tab
    {
    }
}
